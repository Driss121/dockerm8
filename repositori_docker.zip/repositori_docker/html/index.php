<h1>Hello</h1>
<h4>Attempting MySQL connection from PHP...</h4>
<?php
$host = 'mysql';
$user = 'root';
$pass = 'rootpassword';
$db = 'example_db';
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected to MySQL successfully!";
}
?>
